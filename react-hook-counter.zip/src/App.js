import "./styles.css";
import { Counter } from "./Components/Counter";

export default function App() {
  return (
    <div id="body" className="App">
      <Counter />
    </div>
  );
}

export { App };
